import java.io.*;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.EnumSet;
import java.util.Scanner;
import java.util.concurrent.atomic.AtomicLong;

public class Main {


        public static void main(String [] args) throws FileNotFoundException {
            Path currentDirectory  = FileSystems.getDefault().getPath("").toAbsolutePath();
            Scanner scanner = new Scanner(System.in);

            String oldDir = System.setProperty("user.dir", String.valueOf(currentDirectory));


            for (; ; ) {
                System.out.println("Write any command you want: mvp, list, delete, any others under construction please wait.. ");
                String scanneri = scanner.nextLine();
                try {
                    mvpCurrentDirectory(currentDirectory, scanneri);
                    listOfDirectoryOfFiles(currentDirectory, scanneri);
                    enterDirectory(scanneri);
                    //copyFileUsingJava7Files(currentDirectory, scanneri);
                    deleteFromCurrentDirectory(currentDirectory, scanneri);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                if(scanneri.equals("stop")){
                    System.out.println("See you later...");
                    break;
                }
            }
        }

    private static void deleteFromCurrentDirectory(Path currentDirectory, String scanneri) throws IOException {
        if (scanneri.equals("enter")) {
            Files.delete(currentDirectory);
        }
    }

    private static void enterDirectory(String scanneri) throws FileNotFoundException {
        if (scanneri.equals("enter")){
            File myFile = new File(System.getProperty("user.dir"), "localpath.ext");
            InputStream openit = new FileInputStream(myFile);

        }
    }

    private static void listOfDirectoryOfFiles(Path currentDirectory, String scanneri) throws IOException {
        if (scanneri.equals("list")) {
            Files.walkFileTree(currentDirectory, EnumSet.noneOf(FileVisitOption.class), 1, new PrintFiles());
        }
    }

    private static void mvpCurrentDirectory(Path currentDirectory, String scanneri) {
        if (scanneri.equals("mvp")) {
            System.out.println("The current working directory is " + currentDirectory);
        }
    }

    private static void copyFileUsingJava7Files(File currentDirectory, String scanneri) throws IOException {
            if(scanneri.equals("copy")) {
                Files.copy(currentDirectory.toPath(), currentDirectory.toPath());
            }
    }

    private static class PrintFiles extends SimpleFileVisitor<Path> {

            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attr) {
                if (attr.isDirectory()) {
                    try {
                        System.out.format("Directory: %s, size: %d bytes\n", file, getDirSize(file));
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } else if (attr.isRegularFile()) {
                    System.out.format("Regular file: %s, size %d bytes\n", file, attr.size());
                }
                return FileVisitResult.CONTINUE;
            }

            @Override
            public FileVisitResult visitFileFailed(Path file, IOException exc) {
                System.err.println(exc);
                return FileVisitResult.CONTINUE;
            }

            private long getDirSize(Path dirPath) throws IOException {
                final AtomicLong size = new AtomicLong(0L);

                Files.walkFileTree(dirPath, new SimpleFileVisitor<Path>() {
                    @Override
                    public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                        size.addAndGet(attrs.size());
                        return FileVisitResult.CONTINUE;
                    }

                    @Override
                    public FileVisitResult visitFileFailed(Path file, IOException exc) throws IOException {
                        return FileVisitResult.CONTINUE;
                    }
                });

                return size.get();
            }
        }


    }